﻿namespace SjukhusAnställdaPatienter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbSjukhus = new System.Windows.Forms.ComboBox();
            this.cbKommun = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbSjukhus = new System.Windows.Forms.GroupBox();
            this.gbVårdare = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbVårdareEfternamn = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSökVårdare = new System.Windows.Forms.Button();
            this.gbPatient = new System.Windows.Forms.GroupBox();
            this.cbVårdareFörnamn = new System.Windows.Forms.ComboBox();
            this.cbVårdareAvdelning = new System.Windows.Forms.ComboBox();
            this.tbxVårdarePnr = new System.Windows.Forms.TextBox();
            this.lbxSökVårdare = new System.Windows.Forms.ListBox();
            this.btnVäljVårdare = new System.Windows.Forms.Button();
            this.tbxPatientPnr = new System.Windows.Forms.TextBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tbxPatientEfternamn = new System.Windows.Forms.TextBox();
            this.tbxPatientFörnamn = new System.Windows.Forms.TextBox();
            this.gbListSkötare = new System.Windows.Forms.GroupBox();
            this.bgListPatienter = new System.Windows.Forms.GroupBox();
            this.lbxSkötare = new System.Windows.Forms.ListBox();
            this.lbxPatienter = new System.Windows.Forms.ListBox();
            this.btnTabortSkötare = new System.Windows.Forms.Button();
            this.btnTabortPatient = new System.Windows.Forms.Button();
            this.btnMerInfoSkötare = new System.Windows.Forms.Button();
            this.btnMerInfoPatient = new System.Windows.Forms.Button();
            this.gbSjukhus.SuspendLayout();
            this.gbVårdare.SuspendLayout();
            this.gbPatient.SuspendLayout();
            this.gbListSkötare.SuspendLayout();
            this.bgListPatienter.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbSjukhus
            // 
            this.cbSjukhus.FormattingEnabled = true;
            this.cbSjukhus.Location = new System.Drawing.Point(314, 45);
            this.cbSjukhus.Name = "cbSjukhus";
            this.cbSjukhus.Size = new System.Drawing.Size(121, 21);
            this.cbSjukhus.TabIndex = 1;
            // 
            // cbKommun
            // 
            this.cbKommun.FormattingEnabled = true;
            this.cbKommun.Location = new System.Drawing.Point(93, 45);
            this.cbKommun.Name = "cbKommun";
            this.cbKommun.Size = new System.Drawing.Size(121, 21);
            this.cbKommun.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Kommun:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(249, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sjukhus:";
            // 
            // gbSjukhus
            // 
            this.gbSjukhus.Controls.Add(this.cbKommun);
            this.gbSjukhus.Controls.Add(this.cbSjukhus);
            this.gbSjukhus.Controls.Add(this.label2);
            this.gbSjukhus.Controls.Add(this.label1);
            this.gbSjukhus.Location = new System.Drawing.Point(12, 12);
            this.gbSjukhus.Name = "gbSjukhus";
            this.gbSjukhus.Size = new System.Drawing.Size(475, 100);
            this.gbSjukhus.TabIndex = 6;
            this.gbSjukhus.TabStop = false;
            this.gbSjukhus.Text = "Sjukhus";
            // 
            // gbVårdare
            // 
            this.gbVårdare.Controls.Add(this.btnVäljVårdare);
            this.gbVårdare.Controls.Add(this.lbxSökVårdare);
            this.gbVårdare.Controls.Add(this.tbxVårdarePnr);
            this.gbVårdare.Controls.Add(this.cbVårdareAvdelning);
            this.gbVårdare.Controls.Add(this.cbVårdareFörnamn);
            this.gbVårdare.Controls.Add(this.label6);
            this.gbVårdare.Controls.Add(this.cbVårdareEfternamn);
            this.gbVårdare.Controls.Add(this.label5);
            this.gbVårdare.Controls.Add(this.label4);
            this.gbVårdare.Controls.Add(this.label3);
            this.gbVårdare.Controls.Add(this.btnSökVårdare);
            this.gbVårdare.Location = new System.Drawing.Point(12, 118);
            this.gbVårdare.Name = "gbVårdare";
            this.gbVårdare.Size = new System.Drawing.Size(475, 285);
            this.gbVårdare.TabIndex = 7;
            this.gbVårdare.TabStop = false;
            this.gbVårdare.Text = "Vårdare";
            this.gbVårdare.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(246, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Avdelning:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // cbVårdareEfternamn
            // 
            this.cbVårdareEfternamn.FormattingEnabled = true;
            this.cbVårdareEfternamn.Location = new System.Drawing.Point(93, 105);
            this.cbVårdareEfternamn.Name = "cbVårdareEfternamn";
            this.cbVårdareEfternamn.Size = new System.Drawing.Size(121, 21);
            this.cbVårdareEfternamn.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Efternamn:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(246, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Förnamn:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Personnummer: ";
            // 
            // btnSökVårdare
            // 
            this.btnSökVårdare.Location = new System.Drawing.Point(370, 210);
            this.btnSökVårdare.Name = "btnSökVårdare";
            this.btnSökVårdare.Size = new System.Drawing.Size(75, 23);
            this.btnSökVårdare.TabIndex = 0;
            this.btnSökVårdare.Text = "Sök";
            this.btnSökVårdare.UseVisualStyleBackColor = true;
            this.btnSökVårdare.Click += new System.EventHandler(this.btnSökVårdare_Click);
            // 
            // gbPatient
            // 
            this.gbPatient.Controls.Add(this.tbxPatientFörnamn);
            this.gbPatient.Controls.Add(this.tbxPatientEfternamn);
            this.gbPatient.Controls.Add(this.tbxPatientPnr);
            this.gbPatient.Controls.Add(this.comboBox4);
            this.gbPatient.Controls.Add(this.label7);
            this.gbPatient.Controls.Add(this.label8);
            this.gbPatient.Controls.Add(this.label9);
            this.gbPatient.Controls.Add(this.label10);
            this.gbPatient.Location = new System.Drawing.Point(12, 409);
            this.gbPatient.Name = "gbPatient";
            this.gbPatient.Size = new System.Drawing.Size(475, 179);
            this.gbPatient.TabIndex = 8;
            this.gbPatient.TabStop = false;
            this.gbPatient.Text = "Patient";
            // 
            // cbVårdareFörnamn
            // 
            this.cbVårdareFörnamn.FormattingEnabled = true;
            this.cbVårdareFörnamn.Location = new System.Drawing.Point(314, 31);
            this.cbVårdareFörnamn.Name = "cbVårdareFörnamn";
            this.cbVårdareFörnamn.Size = new System.Drawing.Size(121, 21);
            this.cbVårdareFörnamn.TabIndex = 6;
            // 
            // cbVårdareAvdelning
            // 
            this.cbVårdareAvdelning.FormattingEnabled = true;
            this.cbVårdareAvdelning.Location = new System.Drawing.Point(314, 105);
            this.cbVårdareAvdelning.Name = "cbVårdareAvdelning";
            this.cbVårdareAvdelning.Size = new System.Drawing.Size(121, 21);
            this.cbVårdareAvdelning.TabIndex = 7;
            // 
            // tbxVårdarePnr
            // 
            this.tbxVårdarePnr.Location = new System.Drawing.Point(93, 31);
            this.tbxVårdarePnr.Name = "tbxVårdarePnr";
            this.tbxVårdarePnr.Size = new System.Drawing.Size(121, 20);
            this.tbxVårdarePnr.TabIndex = 8;
            this.tbxVårdarePnr.TextChanged += new System.EventHandler(this.tbxVårdarePnr_TextChanged);
            // 
            // lbxSökVårdare
            // 
            this.lbxSökVårdare.FormattingEnabled = true;
            this.lbxSökVårdare.Location = new System.Drawing.Point(12, 154);
            this.lbxSökVårdare.Name = "lbxSökVårdare";
            this.lbxSökVårdare.Size = new System.Drawing.Size(352, 108);
            this.lbxSökVårdare.TabIndex = 9;
            // 
            // btnVäljVårdare
            // 
            this.btnVäljVårdare.Location = new System.Drawing.Point(370, 239);
            this.btnVäljVårdare.Name = "btnVäljVårdare";
            this.btnVäljVårdare.Size = new System.Drawing.Size(75, 23);
            this.btnVäljVårdare.TabIndex = 10;
            this.btnVäljVårdare.Text = "Välj";
            this.btnVäljVårdare.UseVisualStyleBackColor = true;
            // 
            // tbxPatientPnr
            // 
            this.tbxPatientPnr.Location = new System.Drawing.Point(93, 59);
            this.tbxPatientPnr.Name = "tbxPatientPnr";
            this.tbxPatientPnr.Size = new System.Drawing.Size(121, 20);
            this.tbxPatientPnr.TabIndex = 16;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(314, 133);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(246, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Avdelning:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Efternamn:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(246, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Förnamn:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Personnummer: ";
            // 
            // tbxPatientEfternamn
            // 
            this.tbxPatientEfternamn.Location = new System.Drawing.Point(93, 133);
            this.tbxPatientEfternamn.Name = "tbxPatientEfternamn";
            this.tbxPatientEfternamn.Size = new System.Drawing.Size(121, 20);
            this.tbxPatientEfternamn.TabIndex = 17;
            // 
            // tbxPatientFörnamn
            // 
            this.tbxPatientFörnamn.Location = new System.Drawing.Point(314, 59);
            this.tbxPatientFörnamn.Name = "tbxPatientFörnamn";
            this.tbxPatientFörnamn.Size = new System.Drawing.Size(121, 20);
            this.tbxPatientFörnamn.TabIndex = 18;
            // 
            // gbListSkötare
            // 
            this.gbListSkötare.Controls.Add(this.btnMerInfoSkötare);
            this.gbListSkötare.Controls.Add(this.btnTabortSkötare);
            this.gbListSkötare.Controls.Add(this.lbxSkötare);
            this.gbListSkötare.Location = new System.Drawing.Point(510, 17);
            this.gbListSkötare.Name = "gbListSkötare";
            this.gbListSkötare.Size = new System.Drawing.Size(459, 280);
            this.gbListSkötare.TabIndex = 9;
            this.gbListSkötare.TabStop = false;
            this.gbListSkötare.Text = "Skötare";
            // 
            // bgListPatienter
            // 
            this.bgListPatienter.Controls.Add(this.btnMerInfoPatient);
            this.bgListPatienter.Controls.Add(this.btnTabortPatient);
            this.bgListPatienter.Controls.Add(this.lbxPatienter);
            this.bgListPatienter.Location = new System.Drawing.Point(510, 303);
            this.bgListPatienter.Name = "bgListPatienter";
            this.bgListPatienter.Size = new System.Drawing.Size(459, 285);
            this.bgListPatienter.TabIndex = 10;
            this.bgListPatienter.TabStop = false;
            this.bgListPatienter.Text = "Inlagda Patienter";
            // 
            // lbxSkötare
            // 
            this.lbxSkötare.FormattingEnabled = true;
            this.lbxSkötare.Location = new System.Drawing.Point(38, 29);
            this.lbxSkötare.Name = "lbxSkötare";
            this.lbxSkötare.Size = new System.Drawing.Size(396, 199);
            this.lbxSkötare.TabIndex = 0;
            // 
            // lbxPatienter
            // 
            this.lbxPatienter.FormattingEnabled = true;
            this.lbxPatienter.Location = new System.Drawing.Point(38, 29);
            this.lbxPatienter.Name = "lbxPatienter";
            this.lbxPatienter.Size = new System.Drawing.Size(396, 199);
            this.lbxPatienter.TabIndex = 1;
            // 
            // btnTabortSkötare
            // 
            this.btnTabortSkötare.Location = new System.Drawing.Point(359, 234);
            this.btnTabortSkötare.Name = "btnTabortSkötare";
            this.btnTabortSkötare.Size = new System.Drawing.Size(75, 23);
            this.btnTabortSkötare.TabIndex = 2;
            this.btnTabortSkötare.Text = "Tabort";
            this.btnTabortSkötare.UseVisualStyleBackColor = true;
            // 
            // btnTabortPatient
            // 
            this.btnTabortPatient.Location = new System.Drawing.Point(359, 234);
            this.btnTabortPatient.Name = "btnTabortPatient";
            this.btnTabortPatient.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnTabortPatient.Size = new System.Drawing.Size(75, 23);
            this.btnTabortPatient.TabIndex = 3;
            this.btnTabortPatient.Text = "Tabort";
            this.btnTabortPatient.UseVisualStyleBackColor = true;
            // 
            // btnMerInfoSkötare
            // 
            this.btnMerInfoSkötare.Location = new System.Drawing.Point(278, 234);
            this.btnMerInfoSkötare.Name = "btnMerInfoSkötare";
            this.btnMerInfoSkötare.Size = new System.Drawing.Size(75, 23);
            this.btnMerInfoSkötare.TabIndex = 3;
            this.btnMerInfoSkötare.Text = "Mer Info";
            this.btnMerInfoSkötare.UseVisualStyleBackColor = true;
            // 
            // btnMerInfoPatient
            // 
            this.btnMerInfoPatient.Location = new System.Drawing.Point(278, 234);
            this.btnMerInfoPatient.Name = "btnMerInfoPatient";
            this.btnMerInfoPatient.Size = new System.Drawing.Size(75, 23);
            this.btnMerInfoPatient.TabIndex = 4;
            this.btnMerInfoPatient.Text = "Mer Info";
            this.btnMerInfoPatient.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 599);
            this.Controls.Add(this.bgListPatienter);
            this.Controls.Add(this.gbListSkötare);
            this.Controls.Add(this.gbPatient);
            this.Controls.Add(this.gbVårdare);
            this.Controls.Add(this.gbSjukhus);
            this.Name = "Form1";
            this.Text = "--";
            this.gbSjukhus.ResumeLayout(false);
            this.gbSjukhus.PerformLayout();
            this.gbVårdare.ResumeLayout(false);
            this.gbVårdare.PerformLayout();
            this.gbPatient.ResumeLayout(false);
            this.gbPatient.PerformLayout();
            this.gbListSkötare.ResumeLayout(false);
            this.bgListPatienter.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbSjukhus;
        private System.Windows.Forms.ComboBox cbKommun;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbSjukhus;
        private System.Windows.Forms.GroupBox gbVårdare;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbVårdareEfternamn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSökVårdare;
        private System.Windows.Forms.GroupBox gbPatient;
        private System.Windows.Forms.ComboBox cbVårdareAvdelning;
        private System.Windows.Forms.ComboBox cbVårdareFörnamn;
        private System.Windows.Forms.TextBox tbxVårdarePnr;
        private System.Windows.Forms.Button btnVäljVårdare;
        private System.Windows.Forms.ListBox lbxSökVårdare;
        private System.Windows.Forms.TextBox tbxPatientFörnamn;
        private System.Windows.Forms.TextBox tbxPatientEfternamn;
        private System.Windows.Forms.TextBox tbxPatientPnr;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox gbListSkötare;
        private System.Windows.Forms.Button btnMerInfoSkötare;
        private System.Windows.Forms.Button btnTabortSkötare;
        private System.Windows.Forms.ListBox lbxSkötare;
        private System.Windows.Forms.GroupBox bgListPatienter;
        private System.Windows.Forms.Button btnMerInfoPatient;
        private System.Windows.Forms.Button btnTabortPatient;
        private System.Windows.Forms.ListBox lbxPatienter;
    }
}

